package illusionofprogress;

import arc.util.*;
import illusionofprogress.content.*;
import mindustry.mod.*;

public class IOF extends Mod {
    public IOF(){}
    @Override

    public void init(){};
    @Override

    public void loadContent() {
        IOFItems.load();
        IOFLiquids.load();
        IOFBlocks.load();
        IOFUnits.load();
//        IOFPlanet.load();
    }
}


