package illusionofprogress.content;

import arc.graphics.Color;
import mindustry.type.Liquid;

public class IOFLiquids {

    public static Liquid
    PhantomMass, Kerosene, Argonium;

    public static void load() {
        PhantomMass = new Liquid("phantom-mass") {{
            heatCapacity = 0.4f;
            viscosity = 0.7f;
            localizedName = "Phantom Mass";
            boilPoint = 0.5f;
            alwaysUnlocked = false;
            color = IOFPAL.purplCLM;
        }};

        Argonium = new Liquid("argonium") {{
            heatCapacity = 0.8f;
            localizedName = "Argonium";
            explosiveness = 2.35f;
            viscosity = 0.45f;
            temperature = 1.35f;
            alwaysUnlocked = false;
            gas = true;
            color = IOFPAL.argCLM;
        }};
        Kerosene = new Liquid("kerosene"){{
            viscosity = 0.1f;
            temperature = 0.5f;
            flammability = 3;
            explosiveness = 0f;
            alwaysUnlocked = false;
            color = Color.valueOf("607c69");
            heatCapacity = 0;
            localizedName = "Kerosin";
        }};
    }
}
