package illusionofprogress.content;

import arc.graphics.Color;
import arc.math.Mathf;
import mindustry.Vars;
import mindustry.content.*;
import mindustry.entities.effect.*;
import mindustry.entities.pattern.*;
import mindustry.type.*;
import mindustry.world.blocks.distribution.BufferedItemBridge;
import mindustry.world.blocks.distribution.Duct;
import mindustry.world.blocks.environment.StaticWall;
import mindustry.world.blocks.liquid.Conduit;
import mindustry.world.blocks.power.ConsumeGenerator;
import mindustry.world.blocks.power.ImpactReactor;
import mindustry.world.blocks.storage.Unloader;
import mindustry.world.consumers.ConsumeCoolant;
import mindustry.entities.bullet.*;
import mindustry.entities.part.RegionPart;
import mindustry.gen.Sounds;
import mindustry.graphics.Pal;
import mindustry.world.Block;
import mindustry.world.blocks.defense.turrets.ItemTurret;
import mindustry.world.blocks.distribution.Conveyor;
import mindustry.world.blocks.production.*;
import mindustry.world.blocks.storage.CoreBlock;
import mindustry.world.consumers.ConsumeItemFlammable;
import mindustry.world.consumers.ConsumeItemRadioactive;
import mindustry.world.draw.*;
import mindustry.world.meta.*;

import static arc.graphics.g2d.Draw.color;
import static arc.math.Angles.randLenVectors;
import static mindustry.type.ItemStack.with;

public class IOFBlocks {
    public static Block
            //cores*
            /*TODO FIX ->>>*/coreExpact,
            //distribution*
//            /*TODO REG ->>>*/*potokConveyor*/,
            tartrumDuct, potokOverpoint,
            //load || unload*
            potokUnloader,
            //turrets
            xymero,  pintle, embodimement, tear, /*TODO ->>>*/pacto, factor,
            //production
            slateForge,
                    phantomMassExivator,
                    phantomPressater,
                    overloadDrenager,
                    subZero,
            //liquid conduits
            whirlpool,
            //generators(power)
            windthrottleGenerator, speedsterReactor,
            //walls env
            acidicWall;
    public static final Attribute
        slateStone = Attribute.add("dark-slate-stone");
    public static void load() {
        //WALLS ENV
        acidicWall = new StaticWall("acidic-wall"){{
            variants = 2;
            attributes.set(slateStone, 1);
        }};

        //conveyors
        tartrumDuct = new Duct("tartum-duct"){{
            requirements(Category.distribution, with(IOFItems.DarkSlate, 2, IOFItems.inforcium, 1));
            health = 100;
            speed = 1.6f;
            researchCost = with(IOFItems.DarkSlate, 120, IOFItems.inforcium, 100);
        }};
//        potokOverpoint = new BufferedItemBridge("potok-overpoint"){{
//           requirements(Category.distribution, with(IOFItems.DarkSlate, 6));
//           fadeIn = moveArrows = false;
//           range = 5;
//           speed = 50f;
//           arrowSpacing = 5;
//           bufferCapacity = 10;
//           underBullets = true;
//        }};
//        potokUnloader = new Unloader("potok-unloader"){{
//            health = 90;
//            itemCapacity = 2;
//            requirements(Category.distribution, with(IOFItems.DarkSlate, 2, IOFItems.Palladium, 1));
//            speed = 0.8f;
//        }};

        /*liquid section*/
        whirlpool = new Conduit("whirlpool"){{
            requirements(Category.liquid, with(IOFItems.inforcium, 1, IOFItems.BloodStone, 2));
            liquidCapacity = 15f;
            liquidPressure = 1.035f;
            health = 100;
        }};

        //cores*
        coreExpact = new CoreBlock("core-expact") {{
            requirements(Category.effect, BuildVisibility.shown, with(IOFItems.DarkSlate, 1000, IOFItems.BloodStone, 750));
            isFirstTier = true;
            health = 2000;
            size = 3;
            unitType = IOFUnits.meridian;
            alwaysUnlocked = true;
            envDisabled = -1;
        }};

        //crafting
        slateForge = new GenericCrafter("slate-forge") {{
            researchCost = with( IOFItems.BloodStone, 250);
            requirements(Category.crafting, with( IOFItems.BloodStone, 45));
            size = 2;
            localizedName = "Slate Forge";
            ambientSound = Sounds.hum;
            craftTime = 2 *100f;

            craftEffect = new ParticleEffect(){{
                region = "shell";
                line = true;
                randLength = true;
                cone = -361;
                lightOpacity = 0.8f;
                lightScl = 2;
            }};

            itemCapacity = 10;
            drawer = new DrawMulti(new DrawDefault());
            consumeItem(IOFItems.DarkSlateStone, 2);
            hasItems = true;
            outputItem = new ItemStack(IOFItems.DarkSlate, 1);
        }};
        phantomMassExivator = new GenericCrafter("phantom-exvtr") {{
            researchCost = with(IOFItems.DarkSlate, 760, IOFItems.BloodStone, 500, IOFItems.Palladium, 400);
            requirements(Category.crafting, with(IOFItems.DarkSlate, 80, IOFItems.BloodStone, 50, IOFItems.Palladium, 30));
            size = 3;
            health = 250;
            localizedName = "Phantom Mass Mixer";
            ambientSound = Sounds.pulseBlast;
            craftTime = 500f;
            itemCapacity = 20;
            drawer   =  new DrawMulti
                    (
                        new DrawRegion("-bottom"),
                        new DrawLiquidTile(IOFLiquids.PhantomMass, 3) {{drawLiquidLight = true; alpha = 0.25f;}},
                        new DrawDefault()
                    );
            liquidCapacity = 10f;
            consumeItem(IOFItems.BloodStone, 5);
            consumeLiquid(Liquids.cryofluid, 0.5f);
            hasItems = true;
            hasLiquids = true;
            outputLiquid = new LiquidStack(IOFLiquids.PhantomMass, 0.1f);
            squareSprite = false;
        }};
        phantomPressater = new GenericCrafter("phantom-pressator") {{
            //research & cost
            researchCost = with(IOFItems.DarkSlate, 1200,  IOFItems.BloodStone, 1000, IOFItems.Palladium, 600);
            requirements(Category.crafting, with(IOFItems.DarkSlate, 150, IOFItems.BloodStone, 100, IOFItems.Palladium, 100));
            //basic stats
            health = 300;
            size = 3;
            localizedName = "Phantom compressor";
            hasItems = true;
            itemCapacity = 30;
            hasLiquids = true;
            liquidCapacity = 1f;
            squareSprite = true;
            craftTime =  200f;
            ambientSound = Sounds.bioLoop;
            //drawers
            drawer = new DrawMulti(
                    new DrawRegion("-bottom"),
                    new DrawLiquidTile(IOFLiquids.PhantomMass, 1),
                    new DrawPlasma() {{suffix="-plasma-"; plasma1 = IOFPAL.purplCLM; plasma2 = IOFPAL.lightPurpleCLM;}},
                    new DrawDefault()
            );
            //input & output
            consumeItems(with(IOFItems.DarkSlate, 2, IOFItems.Palladium, 2));
            consumeLiquid(IOFLiquids.PhantomMass, 0.1f);
            consumePower(3f);

            outputItem = new ItemStack(IOFItems.PhantomPlate, 1);
        }};



        //turrets
        xymero = new ItemTurret("xymero") {{
           health = 200;
           localizedName = "Xymero";
           drawer = new DrawTurret() {{
               parts.add(new RegionPart("-cp"){{
                   mirror = true;
                   under = true;
                   moves.add(new PartMove(){{
                       y = -1.5f;
                       x = 1.5f;
                       moveRot = -5f;
                       progress = PartProgress.warmup;
                   }});
               }});
           }};
           size = 2;
           requirements(Category.turret, with(
                   IOFItems.DarkSlate, 125,
                   IOFItems.BloodStone, 30,
                   IOFItems.Palladium, 70,
                   IOFItems.PhantomPlate,  100
           ));

            shoot.firstShotDelay = 30f;

            outlineColor = Color.valueOf("2b2b2b");

            range = 300f;
            reload = 60;
            recoil = 1f;
            rotateSpeed = 2f;
            targetAir = true;
            targetGround = true;
            hasLiquids = true;
            liquidCapacity = 40f;
            coolant = new ConsumeCoolant(0.25f);
            coolantMultiplier = 2f;
            consumePower(2.5f);
            hasPower = true;
            squareSprite = false;
            shoot = new ShootSpread(3, 5f);
            shootSound = Sounds.malignShoot;

            //formula -- t = d / s
            float speedForXymero = 14;
            float lifetime2 = range / speedForXymero;

            ammo(
                    IOFItems.PhantomPlate, new BasicBulletType(){
                        {
                            width = 15;
                            speed = speedForXymero;
                            height = 15;
                            damage = 35f;
                            sprite = "large-orb-back";
                            frontColor = IOFPAL.lightPurpleCLM;
                            backColor = IOFPAL.purplCLM;
                            trailWidth = 3;
                            trailLength = 6;
                            trailColor = IOFPAL.purplCLM;
                            pierce = true;
                            pierceCap = 1;
                            lifetime = lifetime2;
                            shootEffect = new ParticleEffect() {{
                                particles = 4;
                                lifetime = 30;
                                cone = -180;
                                sizeFrom = 3;
                                sizeTo = 0;
                                colorFrom = IOFPAL.lightPurpleCLM;
                                colorTo = IOFPAL.purplCLM;
                            }};

                            hitEffect = despawnEffect = new WaveEffect() {{
                                sizeFrom = 15;
                                sizeTo = 0;
                                colorFrom = IOFPAL.lightPurpleCLM;
                                colorTo = IOFPAL.purplCLM;
                                sides = 12;
                                rotateSpeed = 25f;
                            }};
                        }}
            );
        }};
        embodimement = new ItemTurret("embodiment"){{
            size = 3;
            health = 970;
            recoil = 0.1f;
            minWarmup = 6f;
            targetAir = true;
            targetGround = true;
            rotateSpeed = 0.9f;
            maxAmmo = 10;
            shootY = 0.8f;
            range = 250f;
            requirements(Category.turret, with(IOFItems.agzoMechenics, 200, IOFItems.PhantomPlate, 100, IOFItems.DarkSlate, 450));
            reload = 180f;

            drawer = new DrawTurret(){{
                        parts.add(new RegionPart("-wing"){{
                            progress = PartProgress.recoil;
                            mirror = true;
                            moveRot = -10f;
                            moveY = -2f;
                            under = false;
                            moves.add(new PartMove(PartProgress.recoil, 4f, -8f, -8));
                        }});
                    }};

            outlineColor = Pal.darkestGray;
            minWarmup = 0.9f;
            moveWhileCharging = false;
            outlineColor = Color.valueOf("2b2b2b");
            shootSound = IOFSounds.LaserOpen;
            chargeSound = Sounds.lasercharge2;
            coolant = new ConsumeCoolant(2);
            coolantMultiplier = 1.75f;

            ammo(
                    IOFItems.PhantomPlate, new LaserBulletType(){{
                        length = 250f;
                        width = 60f;
                        damage = 650;

                        sideWidth = 12f;
                        sideLength = 30f;
                        sideAngle = 15;
                        lengthFalloff = 0.7f;
                        lightningSpacing = -2f;
                        lightningDelay = 0.2f;

                        hitColor = IOFPAL.lightPurpleCLM;
                        colors = new Color[]{IOFPAL.lightPurpleCLM, IOFPAL.purplCLM, Color.white};
                        shootEffect = new ParticleEffect() {{
                           particles = 50;
                           sizeTo = 4;
                           sizeFrom = 0f;
                           colorTo = IOFPAL.purplCLM;
                           colorFrom = IOFPAL.lightPurpleCLM;
                           cone = 70f;
                           lifetime = 400f;
                        }};
                    }}
            );
        }
    };
        tear = new ItemTurret("tear"){{
           health = 2000;
            requirements(Category.turret, with(IOFItems.agzoMechenics, 200, IOFItems.PhantomPlate, 100, IOFItems.DarkSlate, 450));
           size = 3;
           recoil = 2f;
           maxAmmo = 40;
           shake = 0.15f;
           shootCone = 40;
           inaccuracy = 0f;
           localizedName = "Tear";

           shootSound = IOFSounds.SonicShoot;

           range = 300f;

           drawer = new DrawTurret()
           {{
               parts.addAll(
                       new RegionPart("-mid"){{
                           layerOffset = -0.02f;
                       }},
                       new RegionPart("-barrel"){{
                           under = true;
                           layerOffset = -0.03f;
                           moves.add(new PartMove(PartProgress.recoil, 0, -1F, 0, 0, 0));
                       }},
                       new RegionPart("-stab"){{
                           mirror = true;
                           layerOffset = -0.01f;
                           under = false;
                           moves.add(new PartMove(){{
                               moveRot = -6;
                               moveX = 0;
                               moveY = -2;
                               progress = PartProgress.warmup;
                           }});
                       }}
               );
           }};
           reload = 25F;
           shoot = new ShootSpread(12, 4.25f);

           outlineColor = Color.valueOf("2f2f2f");
           shootY = 8f;
           recoil = 1f;
           rotateSpeed = 3;
           canOverdrive = false;
            ammo (
              IOFItems.inforcium, new BasicBulletType(){{
                  width = 10;
                  speed = 6;
                  height = 22f;

                  shootY = 10;
                  sprite = "illusionofprogress-agrshoot";

                  damage = 750 / 2f;
                  pierceArmor = true;
                  hitColor = Color.valueOf("1c3747");
                  frontColor = Color.white;
                  backColor = IOFPAL.freezePal;

//                  trailEffect = IOFX.mpTrail(frontColor, backColor, 5, 18.5f);
                  trailLength = 10;
                  trailColor = IOFPAL.freezePal;
                  trailWidth = 5f;
                  trailSinScl = 2;
                  trailSinMag = 0.2f;
                  trailInterp = v -> Math.max(Mathf.slope(v), 0.6f);


                  shootEffect = IOFX.Sploosh;
//                  shootEffect = new ParticleEffect(){{
//                     particles = 1;
//                     region = "illusionofprogress-star";
//                     sizeFrom = 6;
//                     strokeFrom = 3;
//                     strokeTo = 0;
//                     lightScl = 3;
//                     spin = 2;
//                     lightColor = Color.white;
//                     sizeTo = 0;
//                     lifetime = 100f;
//                     colorFrom = IOFPAL.freezePal;
//                  }};
                  hitEffect = despawnEffect = new ParticleEffect(){{
                      particles = 1;
                      region = "illusionofprogress-star";
                      sizeFrom = 6;
                      strokeFrom = 3;
                      strokeTo = 0;
                      lightScl = 3;
                      spin = 2;
                      lightColor = Color.white;
                      sizeTo = 0;
                      lifetime = 100f;
                      colorFrom = IOFPAL.freezePal;
                  }};
              }}
            );
        }};


        /*power section*/
        windthrottleGenerator = new ConsumeGenerator("winthrotle-generator"){{
            requirements(Category.power, with(IOFItems.inforcium, 35, IOFItems.DarkSlate, 40, IOFItems.Palladium, 10));
            powerProduction = 1.5f;
            itemDuration = 100f;
            consumeLiquid(Liquids.water, 0.1f);
            hasLiquids = true;
            hasItems = false;
            size = 2;

            ambientSound = Vars.tree.loadSound("ceilling-fan-hum");
            ambientSoundVolume = 0.06f;
            drawer = new DrawMulti(
                    new DrawRegion("-bottom"),
                    new DrawBlurSpin("-rotator", 16f *2){{
                        blurThresh = 0.7f;
                    }},
                    new DrawDefault()
            );
        }};
        speedsterReactor = new ImpactReactor("speedster-pl-reactor"){{
            requirements(Category.power, with(IOFItems.Palladium, 300, IOFItems.DarkSlate, 200, IOFItems.CarbonStick, 150));
            size = 4;
            health = 600;
            powerProduction = 100f;
            itemDuration = 260f;
            itemCapacity = 15;
            liquidCapacity = 10;

            consumeItem(IOFItems.Palladium, 2);
            consumeLiquid(IOFLiquids.Kerosene, 0.1f);
            consumePower(2);

            ambientSound = Sounds.pulse;
            ambientSoundVolume = 0.75f;

            explodeSound = Vars.tree.loadSound("boom");
            explosionDamage = 900;
            explosionRadius = 20;

            lightRadius = 10;
            lightColor = Color.valueOf("fef8e5");

            drawer = new DrawMulti(
              new DrawRegion("-bottom"),
              new DrawPlasma(){{plasma1 = Color.valueOf("ffe599"); plasma2 = Color.valueOf("ffd966"); plasmas = 4;}},
              new DrawGlowRegion(){{suffix="-glow"; alpha = 1.0f; color = Color.valueOf("ffae78");}},
              new DrawDefault()
            );
        }};
}}