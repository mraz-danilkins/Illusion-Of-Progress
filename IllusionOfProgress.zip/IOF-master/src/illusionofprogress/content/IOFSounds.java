package illusionofprogress.content;

import arc.Core;
import arc.assets.AssetDescriptor;
import arc.assets.loaders.SoundLoader;
import arc.audio.Sound;
import illusionofprogress.IOF;
import mindustry.Vars;
import mindustry.mod.Mods;

public class IOFSounds {
    public static final Sound
           LaserOpen = Vars.tree.loadSound("sonic-shoot"),
            SonicShoot = Vars.tree.loadSound("sonic-shoot"),
            RecBoom = Vars.tree.loadSound("boom"),
            CeillingFanHum = Vars.tree.loadSound("ceilling-fan-hum");
}

