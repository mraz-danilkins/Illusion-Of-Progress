package illusionofprogress.content;

import arc.graphics.*;
import arc.graphics.g2d.*;
import arc.math.*;
import arc.math.geom.*;
import arc.struct.*;
import arc.util.*;
import mindustry.ai.*;
import mindustry.ai.types.*;
import mindustry.content.Fx;
import mindustry.content.StatusEffects;
import mindustry.entities.*;
import mindustry.entities.abilities.*;
import mindustry.entities.bullet.*;
import mindustry.entities.effect.*;
import mindustry.entities.part.*;
import mindustry.entities.pattern.*;
import mindustry.gen.*;
import mindustry.graphics.*;
import mindustry.type.*;
import mindustry.type.ammo.*;
import mindustry.type.unit.*;
import mindustry.type.weapons.*;
import mindustry.world.meta.*;

import static arc.graphics.g2d.Draw.*;
import static arc.graphics.g2d.Lines.*;
import static arc.math.Angles.*;
import static mindustry.Vars.*;
import static mindustry.gen.Sounds.none;

public class IOFUnits {

    public static @EntityDef({Unitc.class, Legsc.class})UnitType secretary, admin, gen, major, imperator, grossfurst;

    public static @EntityDef({Unitc.class})UnitType meridian;

    public static @EntityDef({Unitc.class})UnitType /*Champions*/ axiome;



    public static void load() {
        meridian = new UnitType("meridian") {{
            constructor = UnitEntity::create;
            aiController = BuilderAI::new;
            isEnemy = false;
            envEnabled |= Env.space;

            health = 350f;
            speed = 2.5f;
            drag = 0.01f;

            buildSpeed = 1.5f;
            mineTier = 3;
            mineRange = 100f;

            mineWalls = true;
            mineFloor = true;

            faceTarget = true;
            targetAir = false;
            targetGround = true;
            flying = true;

            itemCapacity = 35;

            armor = 0;
            hitSize = 10;

            outlineColor = Color.valueOf("191414");

            engineColor = Color.valueOf("ed1a1a");
            engineOffset = 8;


            parts.add(
                    new RegionPart("-part1") {{
                        x = 0;
                        y = 0;
                        progress = PartProgress.recoil;
                        mirror = false;
                        under = true;
                        moveY = 0.8f;
                    }}
            );

            weapons.add(
                    new Weapon("meridian-bomber") {{
                        x = 0;
                        y = -6;
                        mirror = false;
                        top = false;
                        alternate = false;
                        reload = 50f;
                        shoot = new ShootSpread(6, 30);
                        shootSound = Sounds.artillery;
                        bullet = new BasicBulletType() {{
                            width = 10;
                            height = 10;
                            speed = 0.75f;
                            damage = 20;
                            sprite = "large-bomb";
                            backSprite = "large-bomb-back";
                            trailColor = Color.red;
                            trailWidth = 3f;
                            trailLength = 3;
                            trailEffect = new ParticleEffect() {{
                                line = false;
                                particles = 8;
                                lifetime = 15;
                                offset = 20;
                                length = 12;
                                cone = -35;
                                lenFrom = 6;
                                lenTo = 0;
                                colorFrom = Color.red;
                                colorTo = Color.red;
                            }};
                            splashDamage = 5;
                            splashDamageRadius = 20;

                            frontColor = Color.valueOf("ff1f1f");
                            backColor = Color.valueOf("ff9494");
                        }};
                    }}
            );
        }};

        //spiders

        //TIER I
        secretary = new UnitType("secretary"){{
           constructor = LegsUnit::create;
            aiController = GroundAI::new;

            speed = 0.4F;
            hitSize = 16;
            health = 420f;
            armor = 0f;

            range = 165f;
            targetAir = true;

            stepShake = 0.05f;
            rotateSpeed = 2.5f;
            legCount = 6;
            legStraightness = 0.3f;
            legGroupSize = 2;
            allowLegStep = true;
            legMoveSpace = 1;
            legMaxLength = 1.1f;
            legMinLength = 0.3f;
            legLengthScl = 1.1f;
            legForwardScl = 1.1f;
            legLength = 17f;
            legExtension = -2;
            lockLegBase = true;

            outlineColor = Pal.darkOutline;
            weapons.add(new Weapon("touchGun"){{
                x = 4;
                y = 2;
                top = false;
                mirror = true;
                reload = 170f;
                smoothReloadSpeed = 0.3f;
                range = 120f;
                shootSound = Sounds.malignShoot;
                bullet = new LaserBulletType(150/2f){{
                   length = 120f;
                   width = 20;
                   largeHit = true;
                   shootEffect = new ParticleEffect()
                   {{
                       particles = 2;
                       colorFrom = IOFPAL.malachite;
                       lifetime = 100;
                       cap = true;
                       offset = 30;
                       cone  = 360F;
                       sizeFrom = 7;
                       region = "illusionofprogress-star";
                       spin = 4;
                       lightScl = 4;
                   }};

                    hitEffect = new ParticleEffect()
                    {{
                        particles = 2;
                        colorFrom = IOFPAL.malachite;
                        lifetime = 100;
                        cap = true;
                        offset = 30;
                        cone  = 360F;
                        sizeFrom = 7;
                        region = "illusionofprogress-star";
                        spin = 4;
                        lightScl = 4;
                    }};
                   lifetime = 20f;
                   chargeEffect = new ParticleEffect()
                   {{
                        lifetime = 36f;
                        sizeFrom = 6;
                        length = 3;
                        sizeTo = 0;
                        colorFrom = IOFPAL.darkerMalachite;
                        colorTo = IOFPAL.malachite;
                        line = true;
                   }};
                    splashDamage = 50f;
                    splashDamageRadius = 10;
                   colors = new Color[]{IOFPAL.darkerMalachite, IOFPAL.malachite, Color.white};
                }};
            }});
        }};
        admin = new UnitType("administrator"){{
            constructor = LegsUnit::create;
            aiController = GroundAI::new;
            health = 1080;
            speed = 0.5f;
            faceTarget = false;
            hitSize = 20;
            armor = 3;
            range = 130;
            targetAir = true;
            rotateSpeed = 1.5f;

            legCount = 6;
            legLength = 20f;
            legGroupSize = 2;
            lockLegBase = true;
            legContinuousMove = true;
            legExtension = -3;
            legBaseOffset = 4;
            legMaxLength = 1.1f;
            legMinLength = 0.9f;
            legLengthScl = 0.95f;
            legMoveSpace = 1.2f;

            allowLegStep = true;
            hovering = true;

            weapons.add(
                    new Weapon("illusionofprogress-administrator-weapon"){{
                    shootCone = 45f;
                    mirror = false;
                    rotateSpeed = 2;
                    continuous = true;
                    alwaysContinuous = true;
                    rotate = true;
                    x = 0;
                    y = -3;
                    shootY = 2;
                    layerOffset = 7;
                        parts.addAll(
                                new ShapePart(){{
                                    progress = PartProgress.warmup.delay(0.05f);
                                    color = IOFPAL.malachite;
                                    sides = 5;
                                    hollow = true;
                                    stroke = 0f;
                                    strokeTo = 1f;
                                    radius = 4f;
                                    layer = Layer.effect;
                                    y = 5;
                                    rotateSpeed = -4*1.5f;
                                }}
                        );
                    cooldownTime = 30;
                    shootSound = Sounds.torch;
                    recoil = 1;
                    bullet = new ContinuousFlameBulletType(45/2F){{
                        flareColor = Color.white;
                        hitColor = IOFPAL.malachite;
                        drawFlare = false;
                        shootY = 4;

                        colors = new Color[]{IOFPAL.darkerMalachite, IOFPAL.malachite, Color.white};
                        damageInterval = 10;
                        length = 130;
                        width = 1.5f;
                        pierce = false;
                    }};
            }});
            outlineColor = Pal.darkOutline;
        }};
       gen = new UnitType("gen"){{
            constructor = LegsUnit::create;
            aiController = GroundAI::new;
            speed = 0.66f;
            health = 5000;
            hitSize = 60;
            range = 150;
            armor = 8;

           abilities.add(new ShieldArcAbility(){{
               radius = 36f;
               angle = 82f;
               regen = 0.6f;
               cooldown = 60f * 10f;
               max = 1200f;
               y = -20f;
               width = 6f;
               whenShooting = false;
           }});

            targetAir = targetGround = true;
            rotateSpeed = 1;

            //leg div
           legMoveSpace = 1;
           legMaxLength = 1.5f;
           legMinLength = 0.9f;
           legLengthScl = 0.996f;
           legForwardScl = 0.7f;
           legPhysicsLayer = false;
           legGroupSize = 6;
           legCount = 6;
           legExtension = -5;
           legContinuousMove = true;
           lockLegBase = true;
           rippleScale = 0.25f;
           legBaseOffset = 0;
           legLength = 40;
           allowLegStep = true;
           hovering = true;
           //end region

           immunities = ObjectSet.with(StatusEffects.blasted, StatusEffects.melting, StatusEffects.burning);
           weapons.add(
                   new Weapon("illusionofprogress-generate-fusion"){{
                        shootCone = 15f;
                        mirror = true;
                        alternate = true;
                        shootSound = IOFSounds.SonicShoot;
                        x = -14f;
                        y = 0f;
                        layerOffset = -0.015f;
                        reload = 120/2;
                        recoil = 4F;
                        shootY = 20f;
                        shootX = 22f;
                        shoot = new ShootSpread(){{
                            shots = 3;
                            spread = 5f;
                        }};
                        shake = 2;
                        bullet = new ShrapnelBulletType(){{
                            damage = 200;
                            pierce = true;
                            serrations = 3;
                            serrationWidth = 3f;
                            pierceCap = 5;
                            lifetime = 26;
                            length = 180F;
                            width = 15;
                            serrations = 0;
                            fromColor = Color.white;
                            toColor = IOFPAL.malachite;
                            hitColor = IOFPAL.darkerMalachite;
                        }};
                   }},
                   new Weapon("illusionofprogress-ectogear"){{
                       x = 0; y = -4;
                       recoil = 2;
                       shootCone = 5;

                       mirror = false;
                       alternate = true;
                       rotate = true;
                       rotateSpeed = 2;
                       top = true;
                       shootSound = Sounds.pulseBlast;

                       cooldownTime = 50;
                       reload = 60*3f;
                       shoot.shots = 5;
                       inaccuracy = 0.5f;
                       velocityRnd = 0.1f;

                       bullet = new MissileBulletType(){{
                           weaveMag = 5;
                           weaveScale = 3.5F;
                           damage = 80;
                           speed = 6;
                           autoTarget = false;

                           homingDelay = 0.3F;
                           lifetime = 75f;

                           shootEffect = Fx.lightningShoot;
                           smokeEffect = Fx.shootSmokeSquare;
                           splashDamage = 20;
                           splashDamageRadius = 40;

                           frontColor = Color.white;
                           backColor = IOFPAL.malachite;
                           hitSound = none;

                           width = height = 12f;
                           lightColor = IOFPAL.malachite;
                           trailColor = IOFPAL.malachite;
                           lightRadius = 40f;
                           lightOpacity = 0.6f;

                           trailWidth = 3;
                           trailLength = 20;
                           trailChance = -1;
                           despawnSound = Sounds.dullExplosion;
                           hitEffect = new ExplosionEffect(){{
                               lifetime = 50f;
                               waveStroke = 4f;
                               waveColor = sparkColor = trailColor;
                               waveRad = 30f;
                               smokeSize = 0f;
                               smokeSizeBase = 0f;
                               sparks = 12;
                               sparkRad = 60f;
                               sparkLen = 4f;
                               sparkStroke = 1.5f;
                           }};
                           despawnEffect = Fx.none;
                       }};
                   }}
           );

       }};

       /*CHAMPIONS*/
        axiome = new UnitType("axioma-v1"){{
            localizedName = "Axiome (v1)";
            health = 24000 + 12000F;
            armor = 12;
            speed = 0.64f;
            accel = 0.04f;
            drag = 0.04f;

            rotateSpeed = 0.8f;
            flying = true;
            lowAltitude = true;
            engineSize = 0;

            abilities.add(new RegenAbility(){{
                        amount = 400;
                        percentAmount = 12f;
                    }});

            targetFlags = new BlockFlag[]{BlockFlag.core, null};
            ammoType = new PowerAmmoType(20000);
            weapons.add(
              new Weapon("engine-1"){{
                  x = 16; y = -24;
                  mirror = true;
                  alternate = false;
                  top = true;
                  display = false;
                  rotate = false;
                  alwaysShooting = true;
                  alwaysContinuous = true;
                  parentizeEffects = true;
                  continuous = true;
                  shootSound = none; //By now

                  baseRotation = 180;
                  shootY = 5;

                  bullet = new ContinuousFlameBulletType(){{
                     damage = 10/4F;
                     layer = 110;
                     intervalBullets = 2;
                     intervalRandomSpread = 1;
                     bulletInterval = 2.7f;

                     despawnHit = true;
                     despawnEffect = Fx.none;
                     shootEffect = Fx.none;
                     width = 10;
                     length = 36;
                     colors = new Color[]{Color.valueOf("dc4b4b"), Color.valueOf("ff9191"), Color.white};

                     drawFlare = false;
                     collides = false;
                     divisions = 20;
                        }};
                    }},
                    new Weapon("engine-2"){{
                        x = 20; y = -20;
                        mirror = true;
                        alternate = false;
                        top = true;
                        display = false;
                        rotate = false;
                        alwaysShooting = true;
                        alwaysContinuous = true;
                        parentizeEffects = true;
                        continuous = true;
                        shootSound = none; //By now

                        baseRotation = 180;
                        shootY = 5;

                        bullet = new ContinuousFlameBulletType(){{
                            damage = 10/4F;
                            layer = 110;
                            intervalBullets = 2;
                            intervalRandomSpread = 1;
                            bulletInterval = 2.7f;

                            despawnHit = true;
                            despawnEffect = Fx.none;
                            shootEffect = Fx.none;
                            width = 10;
                            length = 36;
                            colors = new Color[]{Color.valueOf("dc4b4b"), Color.valueOf("ff9191"), Color.white};

                            drawFlare = false;
                            collides = false;
                            divisions = 20;
                        }};
                    }}
            );
        }};
    }
}
