package illusionofprogress.content;

import arc.graphics.Color;
import arc.math.geom.Vec3;
import mindustry.content.Planets;
import mindustry.game.Team;
import mindustry.graphics.Pal;
import mindustry.graphics.g3d.HexMesh;
import mindustry.graphics.g3d.HexSkyMesh;
import mindustry.graphics.g3d.MultiMesh;
import mindustry.maps.generators.PlanetGenerator;
import mindustry.maps.planet.SerpuloPlanetGenerator;
import mindustry.type.Planet;

public class IOFPlanet {
    public static Planet Last;

    public static void load(){
        Last = new Planet("Last", Planets.sun, 2f, 5){{
          generator = new SerpuloPlanetGenerator();
          meshLoader = () -> new HexMesh(this, 7);
          cloudMeshLoader = () -> new MultiMesh(
                  new HexSkyMesh(this, 11, 0.5f, 0.2f, 5, new Color().set(IOFPAL.redAccent), 3, 0.5f, 0.98f, 0.4f)
          );
          launchCapacityMultiplier = launchCapacityMultiplier;
          sectorSeed = 2;
          allowWaves = true;
          allowWaveSimulation = true;
          allowLaunchSchematics = true;
          allowSectorInvasion = true;
          allowLaunchLoadout = true;
          enemyCoreSpawnReplace = true;

          prebuildBase = false;
          ruleSetter = r -> {
            r.waveTeam = Team.malis;
            r.placeRangeCheck = false;
            r.showSpawns = false;
            r.coreDestroyClear = true;
          };
          iconColor = IOFPAL.redAccent;

          atmosphereColor = Color.valueOf("8f1b4b");
          atmosphereRadIn = 0.02f;
          atmosphereRadOut = 0.3f;
          startSector = 0;
            alwaysUnlocked = true;
        }};
    }
};
