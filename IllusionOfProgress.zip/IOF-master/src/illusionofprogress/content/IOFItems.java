package illusionofprogress.content;

import arc.graphics.Color;
import arc.struct.Seq;
import mindustry.type.Item;
import mindustry.graphics.Pal;

public class IOFItems {
    public static Item
            //HELLLLLLLLLLLLLLLLL YE
            BloodStone, Palladium, DarkSlate, PhantomPlate, CarbonStick, agzoMechenics, protectedOxide, inforcium , DarkSlateStone;

    public static final Seq<Item> firstChapter = new Seq<>();
    public static void load() {
        BloodStone = new Item("blood-stone", Color.valueOf("FF4500")) {{
            hardness = 1;
            localizedName = "Blood Stone";
            cost = 1f;
            alwaysUnlocked = false;
        }};
        Palladium = new Item("palladium", Color.valueOf("f1c232")) {{
            hardness = 3;
            localizedName = "Palladium";
            cost = 2;
            charge = 3.5f;
            alwaysUnlocked = false;
        }};

        DarkSlate = new Item("dark-slate", Color.valueOf("232323")) {{
            hardness = 1;
            localizedName = "DarkSlate";
            cost = 2f;
            alwaysUnlocked = false;
        }};

        PhantomPlate = new Item("phantom-plate", Color.valueOf("6f57b4")) {{
            hardness = 2;
            localizedName = "Phantom Plate";
            cost = 3;
            charge = 2.5f;
            alwaysUnlocked = false;
        }};

        DarkSlateStone = new Item("dark-slate-stone", Color.valueOf("232323")) {{
            hardness = 1;
            localizedName = "DarkSlate Stone";
            cost = 2;
            charge = 0;
            alwaysUnlocked = false;
        }};

        CarbonStick = new Item("carbon-stick", Pal.darkestGray){{
            hardness = 5;
            localizedName = "Carbon stick";
            cost = 4;
            radioactivity = 5;
            alwaysUnlocked = false;
        }};
        //TODO -> REWORK SPRITE and Description(Maybe..)
        agzoMechenics = new Item("agzo-metals", Color.magenta){{
            hardness = 10;
            localizedName = "Agzo-Mechenics";
            cost = 6f;
            radioactivity = 0f;
            charge = 100f;
            description = "-A power of sun... In my hands...\n \n -[red]Gives a might!";
            flammability = 0f;
        }};

        protectedOxide = new Item("protected-oxide", Color.valueOf("cc454c")){{
           hardness = 4;
           cost = 4;

           radioactivity = 0;
           charge = 0;
           flammability = 0;
        }};

        inforcium = new Item("inforcium", Color.valueOf("1c3747")){{
            hardness = 5;
            cost = 5;

            radioactivity = 0;
            charge = 3.5f;
            flammability = 0;
            explosiveness = 0;
        }};
        firstChapter.addAll(
          BloodStone, Palladium,
          DarkSlate, PhantomPlate, DarkSlateStone,
          CarbonStick, agzoMechenics, protectedOxide,
          inforcium
        );

}}