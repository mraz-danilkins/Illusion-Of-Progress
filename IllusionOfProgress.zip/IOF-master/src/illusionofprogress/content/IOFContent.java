package illusionofprogress.content;

import mindustry.Vars;
import mindustry.ctype.Content;
import mindustry.ctype.ContentType;

public class IOFContent extends Content {

    @Override
    public ContentType getContentType(){
        return ContentType.error;
    }

    public void load(){
        if(Vars.headless)return;

    }
}
