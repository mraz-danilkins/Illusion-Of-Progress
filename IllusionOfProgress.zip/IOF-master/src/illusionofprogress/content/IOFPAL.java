package illusionofprogress.content;

import arc.graphics.Color;

public class IOFPAL {
    public static Color

            greenCLM = Color.valueOf("50c878"),
            purplCLM = Color.valueOf("342559"),
            lightPurpleCLM = Color.valueOf("9178cf"),
            argCLM = Color.valueOf("c71508"),
            crysCLM = Color.valueOf("43c17f"),
            freezePal = Color.sky,
            smoke = Color.valueOf("868686"),
            malachite = Color.valueOf("84F491FF"),
            darkerMalachite = Color.valueOf("84F49170"),
            redAccent = Color.valueOf("e96d6d");

}
