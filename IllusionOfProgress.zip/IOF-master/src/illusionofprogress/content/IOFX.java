package illusionofprogress.content;

import arc.graphics.g2d.Fill;
import arc.graphics.g2d.Lines;
import arc.math.Rand;
import arc.math.geom.Vec2;
import arc.struct.Seq;
import mindustry.entities.Effect;
import mindustry.graphics.Drawf;


import static arc.graphics.g2d.Draw.alpha;
import static arc.graphics.g2d.Draw.color;
import static arc.graphics.g2d.Lines.stroke;

public class IOFX {
    public static final Rand rand = new Rand();
    public static final Vec2 v = new Vec2();

    public static final Effect

            Sploosh = new Effect(11, e -> {
                color(e.color, IOFPAL.freezePal, e.fin());
                float w = 1.2f +9 * e.fout();
                Drawf.tri(e.x, e.y, w, 32f * e.fout(), e.rotation);
                Drawf.tri(e.x, e.y, w, 3f * e.fout(), e.rotation + 180f);
             }),
            RadSmoke = new Effect(100f, e -> {
                color(IOFPAL.smoke);
                alpha(0.6f);

                rand.setSeed(e.id);
                for(int i = 0; i < 3; i++){
                float len = rand.random(6f), rot = rand.range(40f*2) + e.rotation;

                e.scaled(e.lifetime * rand.random(0.3f, 1f), b -> {
                    v.trns(rot, len * b.finpow());
                    Fill.circle(e.x + v.x, e.y + v.y, 2f * b.fslope() + 0.2f);
            });
        }
    });
}
